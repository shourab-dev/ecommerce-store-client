
<?php $__env->startSection('content'); ?>
<?php $__env->startPush('customCss'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" />
<?php $__env->stopPush(); ?>
<div class="p-4">
   <form action="<?php echo e(route('admin.setting.social.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    
    <div class="card border-0 p-3">
        <button class="btn btn-outline-primary ms-auto rounded-0 " style="width: fit-content;">Update</button>
        <table class="table table-responsive">

            <tr>
                <th style="width: 80px;text-align:center">#</th>
                <th class="ps-4">Social Media</th>
                <th width="60%">Links</th>
            </tr>
            <?php $__currentLoopData = $socialMedias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
            <tr>
                <td style="text-align:center"><?php echo e(++$key); ?></td>
                <td class="ps-4"> <i class="<?php echo e($social->icon); ?> me-2"></i> <?php echo e($social->name); ?></td>
                <td><input type="text" name="social[<?php echo e($social->id); ?>]" class="form-control" value="<?php echo e($social->link); ?>"></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>


   </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/backend/settings/socialMedia.blade.php ENDPATH**/ ?>