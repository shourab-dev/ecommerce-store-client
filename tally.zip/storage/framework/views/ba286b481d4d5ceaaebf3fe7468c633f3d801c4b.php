
<?php $__env->startSection('frontendContent'); ?>
<?php $__env->startPush('customCss'); ?>
<style>
    .spacer {
        margin: 60px auto;
    }

    .bgGradient {
        background: linear-gradient(to right, #86fde719, #ace5c913);
    }

    .orderId:hover {
        color: white;
    }
</style>
<?php $__env->stopPush(); ?>

<div class="container spacer">
    <div class="col-lg-5 mx-auto text-center shadow-sm rounded-lg py-5  bgGradient">
        <img src="<?php echo e(asset('frontend/successIcon.png')); ?>" alt="" style="width: 80px">
        <h3 class="my-2">Payment Successfully Done</h3>
        <h5 class="my-2 btn btn-outline-success orderId"><b>Order ID: <?php echo e($customerOrderId); ?></b></h5>
        <p>We are processing your order and you will be notified via email. If you have any questions please contact us.
        </p>

        <a href="<?php echo e(route('send.invoice', $customerOrderId)); ?>" class="btn btn-dark text-light">Download Invoice <span
                class="ml-2 d-inline-block"><i class="fas fa-angle-double-down"></i></span></a>

    </div>
</div>



<?php $__env->startPush('customJs'); ?>
<script>
    $(function(){

            
            $('.orderId').click(function(){
                var orderId = $(this).text().split(':')[1].trim();
                navigator.clipboard.writeText(orderId);
                const Toast = Swal.mixin({
                toast: true,
                position: 'top',
                showConfirmButton: false,
                timer: 1000,
                timerProgressBar: true,
                
                })
                
                Toast.fire({
                icon: 'success',
                title: 'Order Id Copied'
                })
            })
            })
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendLayouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/frontend/paymentSuccess.blade.php ENDPATH**/ ?>