
<?php $__env->startPush('customerCss'); ?>
<style>
    #profileImage {
        display: none;
    }

    #profileImage~p {
        font-size: 12px;
        text-align: center;
        color: #4a6cf7;
    }

    .profileLabel {
        width: 100%;

    }

    .profile_url {
       
        width: 200px;
        height: 200px;
        border-radius: 50%;
        display: block;
        margin: auto;
        object-fit: cover;
        object-position: center;
        

    }

    .br {
        border-right: 1px solid #ddd;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('customerUi'); ?>

<div class="container p-4">
    <div class="row justify-content-evenly ">
        <div class="card col-lg-8 border-0 shadow">
            <form action="<?php echo e(route('user.profile.update')); ?>" enctype="multipart/form-data" method="POST">
                <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-4 p-4 br">
                    <label for="profileImage" class="profileLabel">
                        <img class="profile_url" src="<?php echo e(auth()->guard('user')->user()->profile_url ?? env('AVATAR').auth()->guard('user')->user()->name); ?>" alt="">
                    </label>
                    <input type="file" id="profileImage" name="profile">
                    <p>Click Profile Picture to Upload new Photo</p>
                </div>
                <div class="col-lg-8 px-lg-5 py-3">
                    <input type="text" value="<?php echo e(auth()->guard('user')->user()->name); ?>" name="name" class="form-control rounded-0 mb-2" placeholder="User Name" >
                    <input type="email" value="<?php echo e(auth()->guard('user')->user()->email); ?>" name="email" class="form-control rounded-0 mb-2" placeholder="User Email" >
                    <input type="text" value="<?php echo e(auth()->guard('user')->user()->details->phone ?? ''); ?>" name="phone" class="form-control rounded-0 mb-2" placeholder="User Phone" >
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <textarea name="address" class="form-control rounded-0 mb-2" placeholder="Address"><?php echo e(auth()->guard('user')->user()->details->address ?? ''); ?></textarea>
                    <button class="btn btn-primary rounded-0 ms-auto d-block">Update Profile</button>
                </div>
            </div>
            </form>
        </div>
        <div class="card col-lg-3 border-0 shadow mt-5 pb-4">
            <h6 class="text-primary my-3">Change Password</h6>
            <form action="">
                <input type="password" name="oldPassword" class="form-control rounded-0 mb-2" placeholder="Old Password">
                <input type="password" name="password" class="form-control rounded-0 mb-2" placeholder="New Password">
                <input type="password" name="password_confirmation" class="form-control rounded-0 mb-2" placeholder="Confirm Password">
                <button class="btn btn-primary rounded-0 ms-auto d-block    ">Update Password</button>
            </form>
        </div>
    </div>
    
</div>


<?php $__env->startPush('customerJs'); ?>

<script>
    const profilInput = document.querySelector(`#profileImage`);
          const profilImg = document.querySelector(`.profile_url`);
          profilInput.addEventListener('change',(e)=>{
            const blob = URL.createObjectURL(e.target.files[0])
            profilImg.src = blob
          })
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customerAuthUi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/user/profile.blade.php ENDPATH**/ ?>