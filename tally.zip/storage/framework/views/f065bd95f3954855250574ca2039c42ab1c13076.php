
<?php $__env->startSection('content'); ?>

<div class="container px-2 py-3">

    <form action="<?php echo e(route('admin.questions.filter')); ?>">
        <div class="row">


            <div class="form-group col-lg-4">
                <br>
                <select name="country" id="country" class="form-control">
                    <option disabled selected> Select Country</option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($country->id); ?>"> <?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group col-lg-4">
                <br>
                <select name="classRoom" id="classRoom" class="form-control">
                    <option disabled selected> Select Class</option>

                </select>
            </div>
            <div class="form-group col-lg-4">
                <br>
                <select name="subject" id="subject" class="form-control">
                    <option disabled selected> Select Subject</option>

                </select>
            </div>
            <div class="form-group mt-3 col-lg-4">
                <br>
                <select name="type" id="questionType" class="form-control">
                    <option disabled selected> Select Type</option>
                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($type->id); ?>"> <?php echo e($type->type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group mt-3 col-lg-3">
                <label for="" class="w-100">
                    From
                    <input type="date" name="from" id="fromDate" class="form-control"></label>
            </div>
            <div class="form-group mt-3 col-lg-3">
                <label for="" class="w-100">
                    To
                    <input type="date" name="to" id="toDate" class="form-control"></label>
            </div>

            <div class="form-group mt-3 col-lg-2">
                <br>
                <button class="btn w-100 rounded-0 btn-primary">Filter</button>
            </div>

        </div>
    </form>



    <div class="card text-center bg-light round-md p-3 border-0 shadow-sm mt-5">
        <table class="table table-responsive table-border">
            <tr>
                <th>
                    #
                </th>
                <th>
                    Question Name
                </th>
                <th>
                    Has PDF
                </th>
                <th>
                    Question Type
                </th>
                <th>
                    Actions
                </th>
            </tr>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td width="5%"><?php echo e($questions->firstItem() + $key); ?></td>
                <td width="40%"><?php echo e($question->question_name); ?></td>
                <td width="10%">
                    <?php if($question->hasPdf > 0): ?>
                    <span class="badge bg-primary"><?php echo e($question->hasPdf); ?> pdf found</span>
                    <?php else: ?>
                    <span class="text-sm "><?php echo e("No pdf found"); ?></span>
                    <?php endif; ?>
                </td>
                <td width="30%">
                    <?php $__empty_1 = true; $__currentLoopData = $question->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <span class="badge bg-primary text-white rounded-0"><?php echo e($type->type); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="badge bg-danger text-white"><?php echo e("Un-sorted"); ?></span>
                    <?php endif; ?>
                </td>
                <td width="25%">
                    <a title="Edit Question" href="<?php echo e(route('admin.questions.show', $question->id)); ?>">
                        <i class="lni lni-eye"></i>
                    </a>
                    <a class="text-danger mx-2" title="Delete Question" href="<?php echo e(route('admin.questions.delete',$question->id)); ?>">
                        <i class="lni lni-trash-can"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>


    </div>


    <?php if($questions->lastPage() > 1): ?>
    <div class="card mt-2 p-2 border-0 shadow-sm">

        <div>

            <?php echo e($questions->appends(request()->query())->links()); ?>

        </div>
    </div>
    <?php endif; ?>



</div>

<?php $__env->startPush('customJs'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script>
    $(function(){
    $('select[name="country"]').change(function(e){
        
        let selectCountry = $(this).val()

        $.ajax({
            url: "<?php echo e(route('admin.questions.classes')); ?>",
            method: 'GET',
            data: {
                country: selectCountry
            },

            success: function(data){
                $('select[name="classRoom"]').empty()
                let res = JSON.parse(data)
                res.map(option => {
                    $('select[name="classRoom"]').append(`<option value="${option.id}">${option.name}</option>`)
                })
            },
            error: function(err){
                
                $('select[name="classRoom"]').empty()
                $('select[name="classRoom"]').append(`<option value="">${err.responseText}</option>`)
            }
        })

    })


    $('select[name="classRoom"]').change(function(e){
        let selectClass = $(this).val()
        
        $.ajax({
        url: "<?php echo e(route('admin.questions.subjects')); ?>",
        method: 'GET',
        data: {
        class: selectClass
        },
        
        success: function(data){
        $('select[name="subject"]').empty()
        let res = JSON.parse(data)
        res.map(option => {
        $('select[name="subject"]').append(`<option value="${option.id}">${option.name}</option>`)
        })
        },
        error: function(err){
        
        $('select[name="subject"]').empty()
        $('select[name="subject"]').append(`<option value="">${err.responseText}</option>`)
        }
        })
    })


 })
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/backend/questions/allQuestions.blade.php ENDPATH**/ ?>