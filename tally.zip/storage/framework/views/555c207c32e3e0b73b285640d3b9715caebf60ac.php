
<?php $__env->startSection('content'); ?>
<div class="p-4">
    <h2>All Books</h2>

    <div class="card border-0 mt-5">
        <div class="table-responsive table-wrapper">
            <table class="table text-center">
                <tr class="bg-light">
                    <th>#</th>

                    <th colspan="2">Book Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Selling Price</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Featured</th>

                    <th></th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($books->firstItem() + $key); ?></td>
                    <td class="col">
                        <img src="<?php echo e($book->thumbnail); ?>" alt=""
                            style="width: 50px;height:50px;object-fit:cover;margin:auto;">
                    </td>
                    <td class="text-start"><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->class->name ?? ''); ?>

                        <?php echo e($book->subject->name ?? ''); ?>

                    </td>
                    <td>
                        <?php if($book->selling_price): ?>
                        <span style="text-decoration: line-through"><?php echo e($book->price); ?> tk</span>
                        <?php elseif($book->price != null): ?>
                        <span class="status-btn success-btn"><?php echo e($book->price); ?> tk</span>
                        <?php else: ?> 
                        
                        <span ><?php echo e("Free"); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($book->selling_price): ?>
                        <span class="status-btn success-btn"><?php echo e($book->selling_price); ?> tk</span>
                        <?php else: ?>
                        --
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="status-btn active-btn"><?php echo e($book->is_ebook == 1 ? "Ebook" : "Physical"); ?></span>
                    </td>
                    <td style="width: 50px">

                        <div class="form-check form-switch toggle-switch d-flex justify-content-center">
                            <input class="form-check-input bookStatusBtn" data-id="<?php echo e($book->id); ?>" type="checkbox"
                                value="<?php echo e(true); ?>" id="toggleSwitch2" <?php echo e($book->status == 1 ? "checked" : ''); ?> >
                        </div>
                    </td>
                    <td style="width: 150px">
                        <a href="<?php echo e(route('admin.books.featured',$book->id)); ?>" class="featuredBtn">
                            <i style="font-size: 1.5rem;" class="lni lni-star-<?php echo e($book->is_featured == 0 ? "empty" : "fill"); ?> text-warning"></i>
                        </a>
                    </td>
                    <td style="width:50px">
                        <a href="<?php echo e(route('admin.books.edit', $book->id)); ?>" class="text-primary"><i
                                class="lni lni-pencil"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">No Books Found!</td>
                </tr>
                <?php endif; ?>


            </table>
        </div>
    </div>
    <div class="mt-4"><?php echo e($books->links()); ?></div>

</div>


<?php $__env->startPush('customJs'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(function(){

            //* AJAX STATUS BUTTON
            $('.bookStatusBtn').change(function(){
                let id = $(this).attr('data-id')
                let url = `<?php echo e(route("admin.books.status","::id")); ?>`;
                url = url.replace('::id', id);
                
                $.ajax({
                    url: url,
                    method: 'GET',
                    success: function(res){
                        const Toast = Swal.mixin({
                            toast: true,
                            position: 'top-right',
                            showConfirmButton: false,
                            timer: 1000,
                        })
                        
                        Toast.fire({
                            icon: 'success',
                            title: res,
                        })
                    },
                });

            })

        })
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/backend/books/allBook.blade.php ENDPATH**/ ?>