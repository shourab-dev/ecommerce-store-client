
<?php $__env->startSection('customerUi'); ?>
<?php $__env->startPush('customerCss'); ?>
<style>
    .bgImage {
        background-image:
            linear-gradient(90deg,
                #fff 12px, 0,
                #99c9f8 15px, 0,
                #f1f5f9 20px, 0,
                #fff 100%);
        background-size: 32px 8px, 32px 16px, 32px 16px;
        background-repeat: space no-repeat;
        background-position: center top, center 6px, center 6px;

    }
</style>
<?php $__env->stopPush(); ?>
<div class="container mt-5">
    <div class="row justify-content-between">
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


        <div class="col-lg-6">
            <div class="rounded shadow py-3 px-4 bg-light my-3  bgImage">
                <div class="row justify-between pt-3 align-items-center">

                    <h4 class="col-sm-6">Order No: #<?php echo e($order->id); ?></h4>
                    <p class="text-sm-end col-sm-6">Transaction ID: <?php echo e($order->transaction_id); ?></p>
                </div>
                <hr>
                <p>Customer Name: <strong><?php echo e(str($order->name)->headline()); ?></strong></p>
                <p>Customer Email: <strong><?php echo e($order->email); ?></strong></p>
                <p>Customer Phone: <strong><?php echo e($order->phone); ?></strong></p>
                <p>Customer Post-Code: <strong><?php echo e($order->post_code); ?></strong></p>
                <p>Customer Address: <strong><?php echo e($order->address); ?></strong></p>
                <p>Number of Items: <?php echo e($order->totalItems); ?> <?php echo e($order->totalItems == 1 ? "piece" : "pieces"); ?></p>
                <hr>
                <h5 class="float-end btn btn-outline-primary">Total Price: <?php echo e($order->amount); ?> tk</h5>
                <a href="<?php echo e(route('send.invoice', $order->id)); ?>" class="btn btn-primary float-start">Donwload
                    Invoice</a>
                <br>
                <br>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    </div>
    <h3>No Invoices found!</h3>
    <?php endif; ?>
    <?php if(count($orders)> 0): ?>

    <div class="container">
        <?php echo e($orders->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customerAuthUi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/user/invoices.blade.php ENDPATH**/ ?>