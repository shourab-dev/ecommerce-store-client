
<?php $__env->startSection('customerUi'); ?>

<div class="p-4">
    <h2 class="mb-4">
        My Orders
    </h2>


    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="my-3">
        <div class="card p-3">

            <div class="row justify-content-between align-items-center">
                <div class="row align-items-center col-lg-5">
                    <h4 class="col-md-6">Order No <span>#<?php echo e($order->id); ?></span></h4>
                    <?php if($order->status == 'Complete'): ?>
                    <span class="col-md-4 col-5 ms-2 my-2 my-lg-0 btn ms-lg-3"
                        style="background:rgba(247, 200, 0, 0.12);">
                        Processing
                    </span>
                    <?php elseif($order->status == 'delivered'): ?>
                    <span class="col-md-4 col-5 ms-2 my-2 my-lg-0 btn ms-lg-3"
                        style="background:rgba(33, 150, 83, 0.12);color: #219653;">
                        Delivered
                    </span>
                    <?php endif; ?>
                </div>
                <p class="col-lg-7 text-lg-end">Transaction Id: <?php echo e($order->transaction_id); ?></p>
            </div>
            <hr>
            <div>
                <h5>Customer Name: <?php echo e(str($order->name)->headline()); ?></h5>
                <p>Phone: <?php echo e($order->phone); ?></p>
                <p>Delivery Address: <?php echo e($order->address); ?></p>
                <p>Total Amount: <?php echo e($order->amount); ?>tk</p>
                <p>Order Placed on: <?php echo e(Carbon\Carbon::parse($order->created_at)->format('d M - Y')); ?> </p>
            </div>
            <hr>
            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div>
                <div class="row align-items-center">
                    <div class="col-lg-2 col-5">
                        <img src="<?php echo e($item->book->thumbnail); ?>" alt="" style="width: 100%;max-width:120px">
                    </div>
                    <div class="col p-0">
                        <p><?php echo e($item->book->title); ?></p>
                        <p><strong><?php echo e($item->sold_price); ?> tk</strong></p>
                        <p>* <?php echo e($item->total_orders); ?></p>
                        <h5>Sub Total: <?php echo e($item->sold_price * $item->total_orders); ?> tk</h5>
                    </div>
                </div>
                <hr>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h4 class="p-3 bg-light">No Books Found</h4>
    <?php endif; ?>


    <span>
        <?php echo e($orders->links()); ?>

    </span>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customerAuthUi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/user/orderDelivered.blade.php ENDPATH**/ ?>