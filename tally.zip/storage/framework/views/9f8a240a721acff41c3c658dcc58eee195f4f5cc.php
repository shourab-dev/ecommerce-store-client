


<?php $__env->startSection('customerUi'); ?>

    <div class="container py-4">
        <h2>Welcome to <?php echo e(env('APP_NAME')); ?> <?php echo e(auth()->guard('user')->user()->name); ?></h2>


        <br>
        <br>
        <br>
        <br>


        <h3>What's New</h3>
        <br>
        
        <div class="row gy-4">
            <?php $__empty_1 = true; $__currentLoopData = $newBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="card">
                    <div class="card-img">
                        <img width="100%" src="<?php echo e($newBook->thumbnail); ?>" alt="<?php echo e($newBook->title); ?>">
                    </div>
                    <div class="card-body">
                        <h4 class="mb-3"><?php echo e($newBook->title); ?></h4>
                        <span class="mb-3"><?php echo e($newBook->class->name); ?></span> 
                        
                        <a target="_blank" href="<?php echo e(route('frontend.product.show', $newBook->slug)); ?>" class="btn btn-outline-primary rounded-0 w-100">View
                            Book</a>
                        
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h4 class="p-3 bg-light">No Books Found</h4>
            <?php endif; ?>
        
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customerAuthUi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/user/dashboard.blade.php ENDPATH**/ ?>