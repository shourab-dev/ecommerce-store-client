<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title><?php echo e(env('APP_NAME')); ?></title>

    <!-- ========== All CSS files linkup ========= -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/lineicons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/materialdesignicons.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/fullcalendar.css')); ?>" />
    <?php echo $__env->yieldPushContent('customCss'); ?>
    <?php echo notifyCss(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/main.css')); ?>" />
</head>

<body>
    <!-- ======== sidebar-nav start =========== -->
    <aside class="sidebar-nav-wrapper">
        <div class="navbar-logo">
            <a href="<?php echo e(route('frontend.home')); ?>">
                <img src="<?php echo e(asset('frontend/logo.png')); ?>" alt="logo" style="height: 50px !important;margin:auto;">
                <h2 style="font-size:1.2rem"><?php echo e(env('APP_NAME')); ?></h2>
            </a>
        </div>
        <?php echo $__env->make('layouts.common.backendSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </aside>
    <div class="overlay"></div>
    <!-- ======== sidebar-nav end =========== -->

    <!-- ======== main-wrapper start =========== -->
    <main class="main-wrapper">
        <!-- ========== header start ========== -->
        <header class="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-6">
                        <div class="header-left d-flex align-items-center">
                            <div class="menu-toggle-btn mr-20">
                                <button id="menu-toggle" class="main-btn primary-btn btn-hover">
                                    <i class="lni lni-chevron-left me-2"></i> Menu
                                </button>
                            </div>
                            <div class="header-search d-none d-md-flex">
                                <form action="#">
                                    <input type="text" placeholder="Search..." />
                                    <button><i class="lni lni-search-alt"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-7 col-6">
                        <div class="header-right">
                          

                            <!-- filter start -->

                            <!-- filter end -->
                            <!-- profile start -->
                            <div class="profile-box ml-15">
                                <button class="dropdown-toggle bg-transparent border-0" type="button" id="profile"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <div class="profile-info">
                                        <div class="info">
                                            <h6><?php echo e(auth()->user()->name); ?></h6>
                                            <?php if(auth()->guard()->check()): ?>

                                            <div class="image">
                                                <img src="<?php echo e(auth()->user()->profile_img_link ?? env('AVATAR').auth()->user()->name); ?>"
                                                    alt="" />
                                                <span class="status"></span>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <i class="lni lni-chevron-down"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profile">
                                    
                                  
                                    <li>
                                        <a href="<?php echo e(route('admin.setting')); ?>"> <i class="lni lni-cog"></i> Settings </a>
                                    </li>
                                    <li>

                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                                                             document.getElementById('logout-form').submit();">
                                            <i class="lni lni-exit"></i> Sign Out
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                            class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                            <!-- profile end -->
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- ========== header end ========== -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'notify::components.notify','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notify::notify'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <!-- ========== MAIN CONTENT STARTS HERE ========== -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- ========== MAIN CONTENT ENDS HERE ========== -->

        
    </main>
    <!-- ======== main-wrapper end =========== -->

    <!-- ========= All Javascript files linkup ======== -->
    <script src="<?php echo e(asset('backend/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/dynamic-pie-chart.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/fullcalendar.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/jvectormap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/world-merc.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/polyfill.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/js/main.js')); ?>"></script>
    <?php echo notifyJs(); ?>
    <?php echo $__env->yieldPushContent('customJs'); ?>
</body>

</html><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/layouts/app.blade.php ENDPATH**/ ?>