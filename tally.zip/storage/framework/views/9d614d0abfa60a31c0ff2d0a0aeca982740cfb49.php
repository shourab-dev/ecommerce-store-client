
<?php $__env->startSection('content'); ?>
<div class="container px-2 py-3">
    <div class="row justify-content-around">

        <div class="col-lg-8">
            <div class="card-style">
                <div class="card-header">
                    <h3 class="mb-2">All Categories</h3>
                </div>

                <div class="table-wrapper table-responsive">
                    <table class="table text-center">
                        <thead>
                            <tr>

                                <th>
                                    <h6>#</h6>
                                </th>
                                <th>
                                    <h6>Category Name</h6>
                                </th>


                                <th>
                                    <h6>Action</h6>
                                </th>
                            </tr>
                            <!-- end table row-->
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $classRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$classRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td class="min-width">
                                    <p><?php echo e(++$key); ?></p>
                                </td>
                                <td class="min-width">
                                    <p><a href="#0"><?php echo e(str()->headline($classRoom->name)); ?></a></p>
                                </td>


                                <td>
                                    <div class="action justify-content-center">
                                        <a href="<?php echo e(route('admin.class.edit', $classRoom)); ?>" class="text-primary me-2">
                                            <i class="lni lni-pencil"></i>
                                        </a>
                                      
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <!-- end table -->
                </div>



            </div>
        </div>

        <div class="card-style col-lg-4 align-self-start">
            <div class="card-header">
                <h3 class="mb-2"><?php echo e(isset($editedClassRoom) ? 'Edit' : 'Add'); ?> Category</h3>
            </div>
            <div class="card-body">
                <form method="post"
                    action="<?php echo e(isset($editedClassRoom) ? route('admin.class.update', $editedClassRoom) :  route('admin.class.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Category Name</label>
                        <input type="text" class="form-control" id="name" name="name"
                            value="<?php echo e(isset($editedClassRoom) ? $editedClassRoom->name : old('name')); ?>"
                            placeholder="Example: Class 1 | Class 2">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger my-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group my-2">
                        <label for="country">Country Name</label>
                        <select name="country_id" id="country" class="form-control">

                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(isset($editedClassRoom)): ?>
                            <option <?php if($editedClassRoom->country_id == $country->id): echo 'selected'; endif; ?> value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger my-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="mt-2 btn btn-outline-primary w-100"><?php echo e(isset($editedClassRoom) ? 'Update
                        Country'
                        : 'Submit'); ?></button>
                </form>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/backend/classRoom/addClassRoom.blade.php ENDPATH**/ ?>