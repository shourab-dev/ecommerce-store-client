
<?php $__env->startSection('customerUi'); ?>

<div class="p-4">
    <h2 class="mb-4">
        My Orders
    </h2>

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $orderBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-3">
            <div class="card">
                <div class="card-img">
                    <img width="100%" src="<?php echo e($orderBook->thumbnail); ?>" alt="<?php echo e($orderBook->title); ?>">
                </div>
                <div class="card-body">
                    <h4 class="mb-3"><?php echo e($orderBook->title); ?></h4>
                    <span class="mb-3">Class 1</span> <span>ICT</span>
                    <?php if($orderBook->is_ebook): ?>
                    <a href="<?php echo e(route('user.myorder.book.view',$orderBook->id)); ?>" class="btn btn-primary w-100">View Book</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h4 class="p-3 bg-light">No Books Found</h4>
        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customerAuthUi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/user/myOrders.blade.php ENDPATH**/ ?>