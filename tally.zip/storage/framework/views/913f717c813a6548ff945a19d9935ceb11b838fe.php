<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Order Invoice <?php echo e(env('APP_NAME')); ?></title>
    <style>
        .orderItems>tr>th,
        .orderItems>tr>td {
            border: 1px solid #eee;
        }
    </style>
</head>

<body>


    <table width="100%" style="font-family: Arial, Helvetica, sans-serif;">
        <tr>
            <td style="border-bottom:1px solid #ddd;">
                <table width="100%" style="margin: 15px 0">
                    <tr>
                        <td width="50%">
                            <a href="<?php echo e(url('/')); ?>"><img width="80px" src="<?php echo e(public_path("frontend/logo.png")); ?>"
                                    alt=""></a>
                        </td>
                        <td width="50%" align="right" style="font-family: Arial, Helvetica, sans-serif">
                            <p style="font-size: 25px;">Invoice</p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>

        <tr>
            <td style="border-bottom:1px solid #ddd;">
                <table width="100%">
                    <tr>
                        <td width="50%" style="font-family: Arial, Helvetica, sans-serif">
                            <p>Date: <?php echo e(Carbon\Carbon::parse($order->created_at)->format("d-m-y") ??
                                today()->format('d-m-y')); ?></p>
                        </td>
                        <td width="50%" align="right" style="font-family: Arial, Helvetica, sans-serif">
                            <p>Invoice No: <?php echo e($order->id); ?></p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table width="100%" style="margin: 15px 0">
                    <tr>
                        <td width="50%" style="font-family: Arial, Helvetica, sans-serif">
                            <strong>Invoice To: </strong>
                            <address style="font-style: normal;color:#888">
                                <?php echo e(str($order->name)->headline()); ?>

                                <br>
                                <?php echo e($order->address); ?>

                                <br>
                                Bangladesh
                            </address>
                        </td>
                        <td width="50%" align="right" style="font-family: Arial, Helvetica, sans-serif">
                            <strong>Pay To:</strong>
                            <address style="font-style: normal;color:#888">
                                <?php echo e(config('app.name')); ?><br />
                                2705 N. Enterprise St<br />
                                Orange, CA 92865<br />
                                contact@koiceinc.com
                            </address>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>


        <tr>

            <td>


                <table width="100%" style="margin:20px 0;" class="orderItems" cellspacing="0" cellpadding="15">
                    <tr style="background: #ececec;">
                        <th>Book</th>
                        <th>Rate</th>
                        <th>Qty</th>
                        <th>Amount</th>
                    </tr>

                    <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="text-align: center">
                        <td class="col-3"><?php echo e($orderItem['book']['title']); ?></td>
                        <td class="col-4 text-center"><?php echo e($orderItem->sold_price); ?> tk</td>
                        <td class="col-2 text-center"><?php echo e($orderItem->total_orders); ?> </td>
                        <td class="col-2 text-end"><?php echo e($orderItem->sold_price * $orderItem->total_orders); ?> tk</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr style="border-top: 1px solid #ccc">
                        <td   colspan="1" style="text-align: center;">Delivery Fee</td>
                        <td   colspan="1"></td>
                        <td   colspan="1"></td>
                        <td  style="text-align:center;" colspan="1"><?php echo e($deliveryFee); ?> tk</td>
                    
                    </tr>
                    <tfoot style="background: #ececec;">
                       
                        <tr>
                            <td align="right" colspan="3" class="text-end border-bottom-0"><strong>Total:</strong></td>
                            <td align="center" class="text-end border-bottom-0"><?php echo e($order->amount); ?> tk</td>
                        </tr>
                    </tfoot>
                </table>


            </td>

        </tr>

        <tr>
            <td>
                <p style="color: #888;font-size: 14px; text-align:center;">NOTE : If you have any question please
                    contact with us. Thank you.</p>
            </td>
        </tr>


    </table>

</body>

</html><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/emails/downloadInvoice.blade.php ENDPATH**/ ?>