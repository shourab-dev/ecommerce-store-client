
<?php $__env->startSection('content'); ?>

<div class="px-4 mt-5">


    <div class="row">

        <div class="col-lg-8">
            <div class="card shadow p-3 border-0">
                <table class="table table-responsive">
                    <tr class="text-center">
                        <th>#</th>
                        <th>User Profile</th>
                        <th>User Name</th>
                        <th>User Phone</th>
                        <th>User Email</th>
                        <th>User Desc</th>
                        <th></th>
                    </tr>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="col text-center"><?php echo e($users->firstItem() + $key); ?></td>
                        <td class="col text-center"><img
                                style="width: 50px;height:50px;border-radius:50%;object-fit:cover; margin:auto;"
                                src="<?php echo e($user->profile_url ?? env('AVATAR').$user->name); ?>" alt=""></td>
                        <td class="col text-center"><?php echo e($user->name); ?></td>
                        <td class="col text-center"><?php echo e($user->phone ?? "not found"); ?></td>
                        <td class="col text-center"><?php echo e($user->email); ?></td>
                        <td class="col text-center"><?php echo e(str()->headline($user->getRoleNames()->first())); ?></td>
                            <td>
                                <a href="<?php echo e(route('role.user.all', $user->id)); ?>" class="btn text-primary" title="Edit User"><i class="lni lni-pencil"></i></a>
                            </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7">
                            <h5>No users found!</h5>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>


                <?php echo e($users->links()); ?>

            </div>
        </div>
        <div class="col-lg-4">
            <form action="<?php echo e($editedUser ? route('role.user.update', $editedUser->id) : route('register')); ?>" method="POST" class="card p-3 border-0 shadow">
                <?php echo csrf_field(); ?>
                <?php if($editedUser): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <input value="<?php echo e(isset($editedUser) ?  $editedUser->name : ''); ?>" type="text" placeholder="User name" class="form-control my-2" name="name">
                <input value="<?php echo e(isset($editedUser) ?  $editedUser->email : ''); ?>" type="text" placeholder="User email" class="form-control my-2" name="email">
                <input type="text" value="<?php echo e(isset($editedUser) ?  $editedUser->phone : ''); ?>" name="phone" placeholder="User Phone Number" class="form-control my-2">
                <input  type="text" placeholder="User Password" class="form-control my-2" name="password">
                <input  type="text" placeholder="Confirm Password" class="form-control my-2"
                    name="password_confirmation">
                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for="profile">
                    User Profile Image
                    <input type="file" name="profile" class="form-control my-2"></label>
                <select name="role" class="form-control">
                    <option disabled selected> Select a Role </option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($user->getRoleNames()->first() == $role->name ? 'selected' : ''); ?>  value="<?php echo e($role->id); ?>"><?php echo e(str($role->name)->headline()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
                <button class="btn btn-outline-primary w-100 rounded-0 mt-3"><?php echo e($editedUser ? "Edit" : "Register"); ?> User</button>


            </form>
        </div>

    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/backend/roles/addUser.blade.php ENDPATH**/ ?>