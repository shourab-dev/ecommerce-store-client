
<?php $__env->startSection('frontendContent'); ?>

<div id="content" class="site-content space-bottom-3 pt-4">
    <div class="container">
        <div class="card">
        <div class="card-header">
            <h1><?php echo e(str($question->question_name)->headline()); ?></h1>
        </div>
        <div class="card-body">
        <p class="text-primary"><?php echo e($question->classRoom->name); ?> / Subject - <?php echo e($question->subject->name); ?></p>
        <p style="font-weight: 600">Publish Date <?php echo e(Carbon\Carbon::parse($question->date)->format('d (D) - M - Y')); ?></p>
        
        <?php $__empty_1 = true; $__currentLoopData = $question->pdfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pdf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
        <a href="<?php echo e(route('frontend.questions.pdf', $pdf->id)); ?>" target="_blank" class="btn btn-sm btn-dark"> (<?php echo e(++$key); ?>) View Quetions PDF </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-danger">No PDF File found!</p>
        <?php endif; ?>
                <hr>
                <h4 class="text-center">Questions Content</h4>
                <hr>
                <?php echo $question->question; ?>

            </div>
        </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendLayouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/frontend/singleQuestion.blade.php ENDPATH**/ ?>