<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="images/favicon.png" rel="icon" />
    <title>Order Invoice - <?php echo e(env('APP_NAME')); ?></title>
    <meta name="author" content="harnishdesign.net">

    <!-- Web Fonts
======================= -->
    

    <!-- Stylesheet
======================= -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets/css/bootstrap.min.css')); ?>" />

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('email/invoice.css')); ?>" />
</head>

<body>
    <!-- Container -->
    <div class="container-fluid invoice-container">
        <!-- Header -->
        <header>
            <div class="row align-items-center">
                <div class="col-sm-7 text-center text-sm-start mb-3 mb-sm-0">
                    <img id="logo" width="80" src="<?php echo e(asset('frontend/logo.png')); ?>" title="<?php echo e(config('app.name')); ?>"
                        alt="<?php echo e(config('app.name')); ?>" />
                </div>
                <div class="col-sm-5 text-center text-sm-end">
                    <h4 class="text-7 mb-0">Invoice</h4>
                </div>
            </div>
            <hr>
        </header>

        <!-- Main Content -->
        <main>
            <div class="row">
                <div class="col-sm-6"><strong>Date:</strong> <?php echo e(Carbon\Carbon::parse($order->created_at)->format("d-m-y") ?? today()->format('d-m-y')); ?></div>
                <div class="col-sm-6 text-sm-end"> <strong>Invoice No:</strong> <?php echo e($order->id); ?></div>

            </div>
            <hr>
            <div class="row">
                <div class="col-sm-6 text-sm-end order-sm-1"> <strong>Pay To:</strong>
                    <address>
                        <?php echo e(config('app.name')); ?><br />
                        2705 N. Enterprise St<br />
                        Orange, CA 92865<br />
                        contact@koiceinc.com
                    </address>
                </div>
                <div class="col-sm-6 order-sm-0"> <strong>Invoiced To:</strong>
                    <address>
                        <?php echo e(str($order->name)->headline()); ?><br />
                        <?php echo e($order->address); ?><br />

                        <?php echo e("Bangladesh"); ?>

                    </address>
                </div>
            </div>

            <div class="card">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead class="card-header">
                                <tr>
                                    <td class="col-3"><strong>Book</strong></td>
                                    <td class="col-2 text-center"><strong>Rate</strong></td>
                                    <td class="col-1 text-center"><strong>QTY</strong></td>
                                    <td class="col-2 text-end"><strong>Amount</strong></td>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="col-3"><?php echo e($orderItem['book']['title']); ?></td>
                                    <td class="col-4 text-center"><?php echo e($orderItem->sold_price); ?> tk</td>
                                    <td class="col-2 text-center"><?php echo e($orderItem->total_orders); ?> </td>
                                    <td class="col-2 text-end"><?php echo e($orderItem->sold_price * $orderItem->total_orders); ?>

                                        tk</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="1" style="text-align: center;">Delivery Fee</td>
                                    <td colspan="1"></td>
                                    <td colspan="1"></td>
                                    <td style="text-align:center;" colspan="1"><?php echo e($deliveryFee); ?> tk</td>

                                </tr>

                            </tbody>
                            <tfoot class="card-footer">

                                <tr>
                                    <td colspan="3" class="text-end border-bottom-0"><strong>Total:</strong></td>
                                    <td class="text-end border-bottom-0"><?php echo e($order->amount); ?> tk</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </main>
        <!-- Footer -->
        <footer class="text-center mt-4">
            <p class="text-1"><strong>NOTE :</strong> If you have any question please contact with us. Thank you.</p>
            <div class="btn-group btn-group-sm d-print-none"> <a href="javascript:window.print()"
                    class="btn btn-light border text-black-50 shadow-none">Print</a> <a href=""
                    class="btn btn-light border text-black-50 shadow-none">
                    Download</a> </div>
        </footer>
    </div>
</body>

</html><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/emails/invoice.blade.php ENDPATH**/ ?>