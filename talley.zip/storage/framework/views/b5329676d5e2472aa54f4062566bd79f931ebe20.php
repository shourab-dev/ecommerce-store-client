
<?php $__env->startSection('content'); ?>
<div class="card-style my-3 ">
    <div class="card-header">
        <h2>Edit User</h2>
    </div>
    <div class="card-body mt-2">
        <form action="<?php echo e(route('role.update', $role->id)); ?>" method="POST" class="d-flex">
            <?php echo csrf_field(); ?>
            <div class="col-10 mx-2"><input type="text" name="name" class="form-control" value="<?php echo e($role->name); ?>">
            </div>
            <button class="btn btn-primary ">Update Role</button>
       
    </div>


    <hr>


   
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$permissionGrp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-lg-12 px-3 py-3 border border-1">
                <div class="row align-items-center justify-content-between">
                    <div class="col-lg-5">
                        <h4><?php echo e(str()->headline($key)); ?></h4>
                    </div>
                    <div class="col-lg-4  text-end">
                        <label>
                            <input type="checkbox" class="inputGrp" data-grp="<?php echo e($key); ?>" value="true"
                                class="form-check-input"> Select
                            All
                        </label>

                    </div>
                </div>

            </div>
            <?php $__currentLoopData = $permissionGrp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 border border-1 d-flex justify-content-center align-items-center">
                <div class="form-group">
                    <label>
                        <input <?php echo e(in_array($permission->id, $allActivePermissions) ? 'checked' : ''); ?> value="<?php echo e($permission->id); ?>" type="checkbox" class="permissionCheckbox" data-group-key="<?php echo e($key); ?>"
                            name="permissions[]">
                        <?php echo e($permission->name); ?></label>
                </div>
            </div>
            <div class="col-lg-9 border border-1">
                <p><?php echo e($permission->details); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </form>



</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('customJs'); ?>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
            //* CLICK ON INPUT GRP CHECKBOX
            let inputGrp = $('input[type="checkbox"].inputGrp');
            inputGrp.on('click', function(e) {

                let grpName = $(this).data('grp');
                let grpValue = $(this).is(':checked');
                let inputBtn  = $('input[data-group-key="' + grpName + '"]')
                let length = inputBtn.length
                

                if(grpValue){
                    inputBtn.prop('checked', true);
                } else{
                    inputBtn.prop('checked', false);
                }


            })

            //* CLICK ON ANY INPUT CHECKBOX
            let inputCheckbox = $('.permissionCheckbox')
            
            inputCheckbox.on('click', function(e){
                let grpName = $(this).data('group-key');
                let allGrpInput = $('input.permissionCheckbox[data-group-key="' + grpName + '"]');
                let allGrpInputChecked = $('input.permissionCheckbox[data-group-key="' + grpName + '"]:checkbox:checked');
                let inputGrp = $(`input[data-grp="${grpName}"].inputGrp`);
                
                if (allGrpInput.length != allGrpInputChecked.length){
                    inputGrp.prop('checked', false);
                }

                

            })






        })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/backend/roles/editRole.blade.php ENDPATH**/ ?>