
<?php $__env->startSection('content'); ?>
<?php $__env->startPush('customCss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/nice-select2.css')); ?>">
<style>
    .nice-select {
        width: 100%;
        padding-top: 0;
    }

    #country,
    #type {
        display: none;
    }
</style>
<?php $__env->stopPush(); ?>

<div class="container px-2 py-3">
    <form enctype="multipart/form-data" action="<?php echo e(route('admin.questions.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row justify-content-around">
            <div class="card border-0 shadow p-3 bg-light col-lg-7">
                <div class="form-group my-2">
                    <label for="name">Question Title <span class="text-danger">*</span></label>
                    <input name="name" type="text" placeholder="Example: BCS Exam Question | Scholl Entrance Exam"
                        class="form-control mb-1" id="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>




                <div class="form-group my-2">
                    <label for="question">Question Content</label>
                    <textarea id="editor" name="question" id="question"></textarea>
                </div>


                <button class="my-2  ms-auto btn btn-primary">Upload Question</button>
            </div>

            <div class="card border-0 shadow p-3 bg-light col-lg-4 align-self-start">
                <div class="row">
                    <div class="form-group my-2 ">
                        <label for="file">PDF Files</label>
                        <input type="file" name="pdfs[]" id="file" class="form-control" multiple
                            accept=".pdf,.jpg,.png,.jpeg,.webp">
                    </div>
                    <div class="form-group my-2 ">
                        <label for="country">Country <span class="text-danger">*</span></label>
                        <select name="country" id="country" class="form-control">

                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group my-2 ">
                        <label for="class">Class <span class="text-danger">*</span></label>
                        <select name="classRoom" id="class" class="form-control">

                           <option disabled selected>No Class Found</option>
                        </select>
                        <?php $__errorArgs = ['classRoom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group my-2 ">
                        <label for="subject">Subject <span class="text-danger">*</span></label>
                        <select name="subject" id="subject" class="form-control">

                           <option disabled selected>No Subject Found</option>
                        </select>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="form-group my-2 ">
                        <label for="type" class="d-block">Type <span class="text-danger">*</span></label>
                        <select name="type[]" id="type" multiple>


                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($type->id); ?>"><?php echo e($type->type); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group my-2 ">
                        <label for="date">Question Date</label>
                        <input type="date" name="date" id="date" class="form-control">
                    </div>


                </div>
            </div>
        </div>
    </form>
</div>


<?php $__env->startPush('customJs'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/37.1.0/classic/ckeditor.js"></script>
<script src="<?php echo e(asset('backend/assets/js/nice-select2.js')); ?>"></script>
<script>
    //* CLASSIC EDITOR
    ClassicEditor
        .create( document.querySelector( '#editor' ) )
        .catch( error => {
        console.error( error );
        } );



    //* INIT NICE SELECT 2 FOR TYPES
    let input = document.querySelector('#country')
    NiceSelect.bind(input, {searchable: true, placeholder: 'Select a Country'});
    
    //* INIT NICE SELECT 2 FOR TYPES
    let input2 = document.querySelector('#type')
    NiceSelect.bind(input2, {searchable: true, placeholder: 'Select Question Type'});
    
</script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script>
    $(function(){
    $('select[name="country"]').change(function(e){
        
        let selectCountry = $(this).val()

        $.ajax({
            url: "<?php echo e(route('admin.questions.classes')); ?>",
            method: 'GET',
            data: {
                country: selectCountry
            },

            success: function(data){
                $('select[name="classRoom"]').empty()
                let res = JSON.parse(data)
                res.map(option => {
                    $('select[name="classRoom"]').append(`<option value="${option.id}">${option.name}</option>`)
                })
            },
            error: function(err){
                
                $('select[name="classRoom"]').empty()
                $('select[name="classRoom"]').append(`<option value="">${err.responseText}</option>`)
            }
        })

    })


    $('select[name="classRoom"]').change(function(e){
        let selectClass = $(this).val()
        
        $.ajax({
        url: "<?php echo e(route('admin.questions.subjects')); ?>",
        method: 'GET',
        data: {
        class: selectClass
        },
        
        success: function(data){
        $('select[name="subject"]').empty()
        let res = JSON.parse(data)
        res.map(option => {
        $('select[name="subject"]').append(`<option value="${option.id}">${option.name}</option>`)
        })
        },
        error: function(err){
        
        $('select[name="subject"]').empty()
        $('select[name="subject"]').append(`<option value="">${err.responseText}</option>`)
        }
        })
    })


 })
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\ecomm\resources\views/backend/questions/addQuestions.blade.php ENDPATH**/ ?>