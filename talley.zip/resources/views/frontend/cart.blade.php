@extends('layouts.frontendLayouts')
@section('frontendContent')
@if (count($data['carts']) > 0)
<div class="site-content bg-light overflow-hidden" id="content">
    <div class="container">
        <header class="entry-header space-top-2 space-bottom-1 mb-2">
            <h1 class="entry-title font-size-7">Your cart: {{ count($data['carts']) }} items</h1>
        </header>
        <div class="row pb-8">
            <div id="secondary" class="sidebar col-lg-6 cart-collaterals" role="complementary">
                <div id="cartAccordion" class="border border-gray-500 bg-white mb-5">
                    <form action="{{ route('checkout') }}" method="POST" class="p-4">
                        <h5 class="mb-4">Check Out Form</h5>
                        @csrf
                        <input type="text" class="form-control my-2" value="{{ auth()->guard('user')->user()->name }}"
                            name="name" placeholder="User Name">
                        @error('name')
                        <span class="text-danger my-2 d-block">{{ $message }}</span>
                        @enderror
                        <input type="text" class="form-control my-2" name="email"
                            value="{{ auth()->guard('user')->user()->email }}" placeholder="Email">
                        @error('email')
                        <span class="text-danger my-2 d-block">{{ $message }}</span>
                        @enderror
                        <input type="text" value="{{ auth()->guard('user')->user()->details->phone  ?? '' }}"
                            class="form-control my-2" name="phone" placeholder="Phone">
                        @error('phone')
                        <span class="text-danger my-2 d-block">{{ $message }}</span>
                        @enderror
                        <input type="number" value="{{ auth()->guard('user')->user()->details->post_code ?? '' }}"
                            class="form-control my-2" name="postCode" placeholder="Post Code">
                        @error('postCode')
                        <span class="text-danger my-2 d-block">{{ $message }}</span>
                        @enderror
                        <textarea name="address" class="form-control my-2"
                            placeholder="Your Address">{{ auth()->guard('user')->user()->details->address ?? '' }}</textarea>
                        @error('address')
                        <span class="text-danger my-2 d-block">{{ $message }}</span>
                        @enderror

                        <div class="p-4d875 border">
                            <table class="shop_table shop_table_responsive">
                                <tbody>
                                    <tr class="order-total">
                                        <th>Delivery</th>
                                        <td data-title="delivery"><strong><span
                                                    class="woocommerce-Price-amount amount"><span
                                                        class="woocommerce-Price-currencySymbol">tk </span>{{
                                                    $data['delivery_fee'] }}</span></strong>
                                        </td>
                                    </tr>
                                    <tr class="order-total">
                                        <th>Product Total</th>
                                        <td data-title="Total"><strong><span
                                                    class="woocommerce-Price-amount amount"><span
                                                        class="woocommerce-Price-currencySymbol">tk </span>{{
                                                    $data['totalPrice']
                                                    }}</span></strong>
                                        </td>
                                    </tr>
                                    <tr class="order-total">

                                        <th>Sub Total</th>

                                        <td data-title="Total"><strong><span
                                                    class="woocommerce-Price-amount amount"><span
                                                        class="woocommerce-Price-currencySymbol">tk </span>{{
                                                    $data['totalPrice'] + $data['delivery_fee']
                                                    }}</span></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width="100%">
                                            <input type="radio" checked class="mr-2" id="cod" name="paymentMethod"
                                                value="cod"><label for="cod">Cash on Delivery</label> <br>
                                            <input type="radio" class="mr-2" id="ssl" name="paymentMethod"
                                                value="ssl"><label for="ssl">SSl Commerce</label>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                </div>
                <div class="wc-proceed-to-checkout">
                    <button type="submit"
                        class="checkout-button button alt wc-forward btn btn-dark btn-block rounded-0 py-4">Proceed
                        to checkout</button>
                </div>
                </form>
            </div>
            <div id="primary" class="content-area col-lg-6">
                <main id="main" class="site-main ">
                    <div class="page type-page status-publish hentry">

                        <div class="entry-content">
                            <div class="woocommerce">
                                <form class="woocommerce-cart-form table-responsive" action="cart.html#" method="post">
                                    <table
                                        class="shop_table shop_table_responsive cart woocommerce-cart-form__contents">
                                        <thead>
                                            <tr>
                                                <th class="product-name">Product</th>
                                                <th class="product-price">Price</th>
                                                <th class="product-price">Total</th>
                                                <th class="product-remove">&nbsp;</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            @foreach ($data['carts'] as $cart)

                                            <tr class="woocommerce-cart-form__cart-item cart_item">
                                                <td class="product-name" data-title="Product">
                                                    <div class="d-flex align-items-center">
                                                        <a
                                                            href="{{ route('frontend.product.show', $cart->books->slug) }}">
                                                            <img src="{{ $cart->books->thumbnail }}"
                                                                style="max-width: 100px"
                                                                class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image"
                                                                alt>
                                                        </a>
                                                        <div class="ml-3 m-w-200-lg-down">
                                                            <a
                                                                href="{{ route('frontend.product.show', $cart->books->slug) }}">{{
                                                                $cart->books->title }} ({{ $cart->amount }} pieces)</a>
                                                            @if (isset($cart->books->author))

                                                            <a href="cart.html#"
                                                                class="text-gray-700 font-size-2 d-block"
                                                                tabindex="0">{{ $cart->books->author->name }}</a>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="product-price" data-title="Price">
                                                    <span class="woocommerce-Price-amount amount"> {{
                                                        $cart->books->selling_price ?? $cart->books->price }} <span
                                                            class="woocommerce-Price-currencySymbol">tk</span></span>
                                                </td>
                                                <td class="product-price" data-title="Price">
                                                    <span class="woocommerce-Price-amount amount"> {{
                                                        ($cart->books->selling_price ?? $cart->books->price) *
                                                        $cart->amount }} <span
                                                            class="woocommerce-Price-currencySymbol">tk</span></span>
                                                </td>


                                                <td class="product-remove">
                                                    <a href="{{ route('cart.remove', $cart->id) }}" class="remove"
                                                        aria-label="Remove this item">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            xmlns:xlink="http://www.w3.org/1999/xlink" width="15px"
                                                            height="15px">
                                                            <path fill-rule="evenodd" fill="rgb(22, 22, 25)"
                                                                d="M15.011,13.899 L13.899,15.012 L7.500,8.613 L1.101,15.012 L-0.012,13.899 L6.387,7.500 L-0.012,1.101 L1.101,-0.012 L7.500,6.387 L13.899,-0.012 L15.011,1.101 L8.613,7.500 L15.011,13.899 Z" />
                                                        </svg>
                                                    </a>
                                                </td>
                                            </tr>
                                            @endforeach

                                            <tr>
                                                <td colspan="5" class="actions">
                                                    <a href="{{ route('cart.all.items') }}" class="btn btn-dark">Update
                                                        Cart</a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </form>
                            </div>
                        </div>

                    </div>
                </main>
            </div>

        </div>
    </div>
</div>
@else
<div class="container" style="height: 50vh">
    <div class="row h-100 justify-content-center align-items-center">
        <div class="cnt text-center">
            <h2 class="text-center">You have no Items in your Cart!</h2>
            <a class="btn btn-dark mt-2 rounded-0" href="{{ route('frontend.product.show') }}">Go to Shop</a>
        </div>
    </div>
</div>
@endif

@endsection